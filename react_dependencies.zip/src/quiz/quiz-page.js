function QuizPage() {
  return (
    <main>
      <h1>Quiz</h1>
      <p>This is the quiz page ❓</p>
    </main>
  );
}

export default QuizPage;
